﻿namespace SizeOperations
{
    public class SizeOperations
    {
        public static void Main()
        {
        }
    }
}
