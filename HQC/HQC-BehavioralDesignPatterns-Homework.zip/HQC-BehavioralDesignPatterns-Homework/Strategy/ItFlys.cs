﻿using System;

namespace KPK_15_DesignPatterns.Strategy
{
    class ItFlys : IFlys
    {
        public String Fly()
        {
            return "Flying High";
        }
    }
}
