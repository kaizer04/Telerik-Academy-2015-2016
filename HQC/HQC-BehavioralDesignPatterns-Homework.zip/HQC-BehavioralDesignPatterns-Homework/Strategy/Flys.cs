﻿using System;

namespace KPK_15_DesignPatterns.Strategy
{
    public interface IFlys
    {
        String Fly();
    }
}
