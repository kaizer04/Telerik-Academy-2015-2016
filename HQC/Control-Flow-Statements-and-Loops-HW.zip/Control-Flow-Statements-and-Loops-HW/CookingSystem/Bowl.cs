﻿namespace CookingSystem
{
    public class Bowl
    {
        public Bowl()
        {
        }

        public void Add(Vegetable vegetableToAdd)
        { 
        }
    }
}
