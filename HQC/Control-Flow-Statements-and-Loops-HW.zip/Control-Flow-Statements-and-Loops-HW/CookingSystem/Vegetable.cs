﻿namespace CookingSystem
{
    public class Vegetable
    {
        public Vegetable()
        {      
        }

        public void Peel()
        {
            ////...
        }

        public void Cut()
        {
            ////...
        }
    }
}
