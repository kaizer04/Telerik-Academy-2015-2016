﻿namespace CookingSystem
{
    public class Potato : Vegetable
    {
        public Potato()
        {
        }
    }
}
