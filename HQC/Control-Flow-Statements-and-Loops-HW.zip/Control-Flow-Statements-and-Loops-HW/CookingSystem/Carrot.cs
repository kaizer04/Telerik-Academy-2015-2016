﻿namespace CookingSystem
{
    public class Carrot : Vegetable
    {
        public Carrot()
        {
        }
    }
}
