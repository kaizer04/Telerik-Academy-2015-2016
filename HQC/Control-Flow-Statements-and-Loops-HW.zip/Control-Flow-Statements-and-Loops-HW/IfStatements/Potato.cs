﻿namespace IfStatements
{
    public class Potato
    {
        public Potato()
        {
        }

        public bool HasBeenPeeled { get; set; }

        public bool IsFresh { get; set; }
    }
}
