module.exports = {
    categories: [
        'Movies',
        'Hip-hop',
        'Chalgiika bace',
        'Dogs',
        'Cats'
    ]
};