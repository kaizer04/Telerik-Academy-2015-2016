var homeController = function() {

    //function all(context) {
    //    templates.get('home')
    //        .then(function(template) {
    //            context.$element().html(template());
    //        });
    //}

    //function all(context) {
    //    var cookies;
    //    data.cookies.get()
    //        .then(function(res) {
    //            cookies = res.result;
    //            //console.log(cookies);
    //            return templates.get('home');
    //        })
    //        .then(function(template) {
    //            context.$element().html(template(home));
    //        });
    //}
    //
    //return {
    //    all: all
    //};
}();