﻿namespace Movies.Web.Infrastructure
{
    public interface IMapFrom<T>
    {
    }
}