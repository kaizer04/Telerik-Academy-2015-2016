﻿namespace ForumSystem.Data.Common.Models
{
    public interface IOrderable
    {
        int OrderBy { get; set; }
    }
}
