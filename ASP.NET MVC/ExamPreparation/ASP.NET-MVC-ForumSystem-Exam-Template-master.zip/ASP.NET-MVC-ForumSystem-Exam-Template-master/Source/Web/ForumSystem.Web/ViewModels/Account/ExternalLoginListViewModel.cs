﻿namespace ForumSystem.Web.ViewModels.Account
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}