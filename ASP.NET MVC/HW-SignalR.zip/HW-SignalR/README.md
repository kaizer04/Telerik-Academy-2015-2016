# SignalR Homework
1. Create the Ping Pong game for two players with SignalR. You can use external libraries like CGWeb.

![ping-pong](ping-pong.png)