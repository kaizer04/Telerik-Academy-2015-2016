﻿namespace BitCalculator.ViewModels
{
    public class EntityViewModel
    {
        public string Name { get; set; }

        public double Value { get; set; }
    }
}