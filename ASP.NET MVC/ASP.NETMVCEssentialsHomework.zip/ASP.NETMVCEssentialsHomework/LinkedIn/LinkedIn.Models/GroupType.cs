﻿namespace LinkedIn.Models
{
    public enum GroupType
    {
        Professional,
        Networking,
        NonProfit,
        Conference,
        Corporate
    }
}
